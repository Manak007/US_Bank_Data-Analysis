# Data

The raw dataset is not stored in this repository. To reproduce the analysis:

1. Go to [FDIC Bank Data Downloads](https://www.fdic.gov/bank-data-guide/data-downloads).
2. Download the institution-level **Financials** file for the **Q3 2025** reporting period (report date 2025-09-30).
3. Save it in this folder as `Financial_10_17_2026.csv`.

Expected shape: **4,388 rows × 161 columns**.

## Key fields used

| Field | Meaning |
|---|---|
| `CERT` | FDIC certificate number (unique bank ID) |
| `NAME`, `STNAME` | Institution name and state |
| `ASSET` | Total assets ($ thousands) |
| `DEP` | Total deposits ($ thousands) |
| `NETINC` | Net income ($ thousands) |
| `ROA` | Return on assets (%) |
| `ROE` | Return on equity (%) |
| `NIMY` | Net interest margin (%) |
| `LNLSDEPR` | Net loans & leases to deposits (%) |
| `RBCRWAJ` | Total risk-based capital ratio (%) |
